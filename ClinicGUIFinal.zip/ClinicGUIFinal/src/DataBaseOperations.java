
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DataBaseOperations {

    Connection con;

    public DataBaseOperations() {

        try {
            con = DriverManager.getConnection("jdbc:sqlite:first.db");
            System.out.println("connected!");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public boolean addNewPatient(Patient p) {
        try {
            PreparedStatement stmt = con.prepareStatement("insert into patient(id,name,age,phone,email,gender) values(?,?,?,?,?,?)");
            stmt.setInt(1, p.getID());
            stmt.setString(2, p.getName());
            stmt.setInt(3, p.getAge());
            stmt.setString(4, p.getPhone());
            stmt.setString(5, p.getEmail());
            stmt.setString(6, p.getGender());
            stmt.executeUpdate();
            return true;
        } catch (Exception ex) {
           // System.out.println(ex);
            return false;
        }

    }
   public  ArrayList<String> getDoctorsSpecialities(){
        try {
            PreparedStatement stmt = con.prepareStatement("select distinct speciality from Doctor"); 
            ResultSet rs= stmt.executeQuery();
            ArrayList<String> sp=new ArrayList<>();
            while(rs.next()){
                sp.add(rs.getString(1));
            }
            return sp;
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }

    
    }
   public  ArrayList<String> getDoctorsName(String n){
        try {
            PreparedStatement stmt = con.prepareStatement("select distinct name from Doctor where speciality=?"); 
            stmt.setString(1, n);
            ResultSet rs= stmt.executeQuery();
            ArrayList<String> names=new ArrayList<>();
            while(rs.next()){
                names.add(rs.getString(1));
            }
            return names;
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }

    
    }
}
